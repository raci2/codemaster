produtos = []
vendas = []
numero_venda = 1